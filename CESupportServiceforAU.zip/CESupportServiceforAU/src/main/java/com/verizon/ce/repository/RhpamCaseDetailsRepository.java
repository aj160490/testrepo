package com.verizon.ce.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.verizon.ce.domains.CaseDetails;

@Repository
public interface RhpamCaseDetailsRepository extends JpaRepository<CaseDetails, String>{

	
	
	CaseDetails findBynfId(String nfId);

}
