package com.verizon.ce.domains;

public class TaskResponse {

	private String taskName;
	private String startDate;
	private long startDateMillis;
	private long endDateMillis;
	private String endDate;
	private int taskId;
	private long parentContainerId;
	private long rootContainerId;
	private String parentName;
	private String processId;
	private String taskType;
	private String taskStatus;
	private long sourceObjectId;
	private String humanTaskId;
	private String humanTaskOwner;
	private String humanTaskStatus;
	private TaskResponse[] subWorkFlow;

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public long getStartDateMillis() {
		return startDateMillis;
	}

	public void setStartDateMillis(long startDateMillis) {
		this.startDateMillis = startDateMillis;
	}

	public long getEndDateMillis() {
		return endDateMillis;
	}

	public void setEndDateMillis(long endDateMillis) {
		this.endDateMillis = endDateMillis;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public int getTaskId() {
		return taskId;
	}

	public void setTaskId(int taskId) {
		this.taskId = taskId;
	}

	public long getParentContainerId() {
		return parentContainerId;
	}

	public void setParentContainerId(long parentContainerId) {
		this.parentContainerId = parentContainerId;
	}

	public long getRootContainerId() {
		return rootContainerId;
	}

	public void setRootContainerId(long rootContainerId) {
		this.rootContainerId = rootContainerId;
	}

	public String getParentName() {
		return parentName;
	}

	public void setParentName(String parentName) {
		this.parentName = parentName;
	}

	public String getProcessId() {
		return processId;
	}

	public void setProcessId(String processId) {
		this.processId = processId;
	}

	public String getTaskType() {
		return taskType;
	}

	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}

	public String getTaskStatus() {
		return taskStatus;
	}

	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}

	public long getSourceObjectId() {
		return sourceObjectId;
	}

	public void setSourceObjectId(long sourceObjectId) {
		this.sourceObjectId = sourceObjectId;
	}

	public String getHumanTaskId() {
		return humanTaskId;
	}

	public void setHumanTaskId(String humanTaskId) {
		this.humanTaskId = humanTaskId;
	}

	public String getHumanTaskOwner() {
		return humanTaskOwner;
	}

	public void setHumanTaskOwner(String humanTaskOwner) {
		this.humanTaskOwner = humanTaskOwner;
	}

	public String getHumanTaskStatus() {
		return humanTaskStatus;
	}

	public void setHumanTaskStatus(String humanTaskStatus) {
		this.humanTaskStatus = humanTaskStatus;
	}

	public TaskResponse[] getSubWorkFlow() {
		return subWorkFlow;
	}

	public void setSubWorkFlow(TaskResponse[] subWorkFlow) {
		this.subWorkFlow = subWorkFlow;
	}

}
