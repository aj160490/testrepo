package com.verizon.ce.apis;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.verizon.ce.domains.MediatorProxyRequest;
import com.verizon.ce.domains.ProcessNode;
import com.verizon.ce.domains.RootNode;
import com.verizon.ce.domains.TaskResponse;

@Component
public class TaskServiceApiCalls {

    private RestTemplate restTemplate;
	
    @Autowired
	public TaskServiceApiCalls(RestTemplateBuilder restTemplateBuilder, 
			@Value("${api.username}") String userName, @Value("${api.password}") String password) {
		restTemplate = restTemplateBuilder.basicAuthentication(userName, password).build();
	}


	@Value("${app.reflow.task-status-tree-url}")
	private String taskStatusTreeUrl;
	
	@Value("${app.reflow.nodes-url}")
	private String nodesUrl;
	
	@Value("${app.reflow.task-url}")
	private String reflowTaskUrl;
	
	@Value("${app.mediatorProxyName.url}")
	private String mediatorProxyNameUrl;
	
	static final Logger logger = LoggerFactory.getLogger(TaskServiceApiCalls.class);

	public List<TaskResponse> getTaskResponse(String caseId, String containerName, String taskType, String status) {
		logger.info(" Start getTaskResponse");
		logger.info(" caseId := "+caseId+ " containerName := "+containerName);
		logger.info(" taskType := "+taskType+ " taskStatus := "+status);
		TaskResponse[] taskResponse = null;
		List<TaskResponse> lst = new ArrayList<>();
		String taskStatusTreeExtendedURL = taskStatusTreeUrl.replace("[container-name]", containerName);
		taskStatusTreeExtendedURL = taskStatusTreeExtendedURL + "/" + caseId;
			taskStatusTreeExtendedURL += "?taskType="+taskType+"&status="+status;
		
		logger.info(" taskStatusTreeExtendedURL:= "+taskStatusTreeExtendedURL);
		ResponseEntity<TaskResponse[]> response = null;
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<?> request = new HttpEntity<>(headers);
		try {
			response = restTemplate.exchange(taskStatusTreeExtendedURL, HttpMethod.GET, request, TaskResponse[].class);
			logger.info(" Response  := "+response);
		} catch (RestClientException e) {
			logger.error("  Error in fetching task reponse "+ e);
			throw new RestClientException("Error in fetching task reponse ", e);
		}
		if (response.getStatusCode() ==  HttpStatus.OK && "not completed".equalsIgnoreCase(status)) {
			taskResponse = response.getBody();
			  lst = Arrays.asList(taskResponse).stream()
					.filter(l -> l.getTaskName().equals("Manual Task")).collect(Collectors.toList());
			  logger.info("  Manual Task Response List := "+lst);
		}else {
			taskResponse = response.getBody();
			lst = Arrays.asList(taskResponse).stream().collect(Collectors.toList());
			
		}
		
		
		logger.info(" End getTaskResponse");
		return lst;		
	}
	
	
	public String startReflowTask(String requestBody ) {
		logger.info(" startReflowTask");
		logger.info(" Request body := "+requestBody);
		ResponseEntity<String> response = null;
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		
		logger.info(" mediatorProxyNameUrl := "+mediatorProxyNameUrl);
		
		HttpEntity<?> request = new HttpEntity<>(requestBody,headers);
		String responsebody = null;
		
		try {
			response = restTemplate.exchange(mediatorProxyNameUrl, HttpMethod.POST, request, String.class);
			logger.info(" Response  := "+response);
		} catch (RestClientException e) {
			logger.error("  Error in Reflowing the task reponse "+ e.getMessage());
			throw new RestClientException("Error in Reflowing the task reponse "+e.getMessage(), e);
		}
		logger.info("HTTP Response"+response.getStatusCode().toString());
		
		if(response.getStatusCode()==HttpStatus.OK) {
			responsebody = response.getBody();
			return responsebody;
		}
		return responsebody;
	}
	
	public String startReflowTask(long parentContainerId, String containerName, String taskName) {
		
		logger.info(" startReflowTask");
		logger.info(" parentContainerId := "+parentContainerId+ " containerName := "+containerName +" taskType := "+taskName);
		String reflowTaskExtendedURL = reflowTaskUrl.replace("[container-name]", containerName);
		reflowTaskExtendedURL = reflowTaskExtendedURL + "/" + parentContainerId + "/" +"taskcompletion";
		reflowTaskExtendedURL += "/"+taskName;
		
		logger.info(" reflowTaskExtendedURL:= "+reflowTaskExtendedURL);
		ResponseEntity<String> response = null;
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.TEXT_PLAIN));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HashMap<String, String> body = new HashMap<String, String> ();
		HttpEntity<?> request = new HttpEntity<>(body,headers);
		
		try {
			response = restTemplate.exchange(reflowTaskExtendedURL, HttpMethod.PUT, request, String.class);
			logger.info(" Response  := "+response);
		} catch (RestClientException e) {
			logger.error("  Error in Reflowing the task reponse "+ e.getMessage());
			throw new RestClientException("Error in Reflowing the task reponse "+e.getMessage(), e);
		}
		logger.info(" startReflowTask");
		logger.info(response.getBody().toString());
		return response.getStatusCode().toString();
	} 
	
	public Integer getNodeId(long parentContainerId, String containerName) {
		logger.info(" Start getNodeId");
		logger.info(" parentContainerId "+parentContainerId + "containerName :="+containerName);
		RootNode rootNode = null;
		Integer id = null;
		String nodesExtendedURL = nodesUrl.replace("[container-name]", containerName);
		nodesExtendedURL = nodesExtendedURL +"/" + parentContainerId;
		nodesExtendedURL += "/nodes";
		logger.info(" nodesExtendedURL := "+nodesExtendedURL);
		ResponseEntity<RootNode> response = null;
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<?> request = new HttpEntity<>(headers);
		try {
			response = restTemplate.exchange(nodesExtendedURL, HttpMethod.GET, request, RootNode.class);
			logger.info(" nodeId Response := "+response);
		} catch (RestClientException e) {
			logger.error(" Error in fetching nodeid ");
			throw new RestClientException("Error in fetching nodeid ", e);
		}
		if (response.getStatusCode() ==  HttpStatus.OK) {
			rootNode =  response.getBody();
			Optional<ProcessNode> optional = Arrays.asList(rootNode.getProcessNodes()).stream()
					.filter(l -> l.getName().equals("Restart the task")).findFirst();
			if (optional.isPresent()) {
				id = optional.get().getId();
			}
			logger.info(" Task Id := "+id);
		}
		logger.info(" End getNodeId := ");
		return id;		
	}
	
	public void reflowNode(Integer nodeId, long parentContainerId, String containerName) {
		logger.info(" Start reflowNode");
		logger.info("nodeId := "+nodeId +" parentContainerId :=  "+parentContainerId + " containerName := "+containerName);
		String nodesExtendedURL = nodesUrl.replace("[container-name]", containerName);
		nodesExtendedURL = nodesExtendedURL +"/" + parentContainerId;
		nodesExtendedURL += "/nodes";
		nodesExtendedURL += "/" + nodeId;
		logger.info(" nodesExtendedURL := "+nodesExtendedURL);
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<?> request = new HttpEntity<>(headers);
		try {
			restTemplate.exchange(nodesExtendedURL, HttpMethod.POST, request, String.class);
		} catch (RestClientException e) {
			logger.error(" Error in reflow node");
			throw new RestClientException("Error in reflow node", e);
		}
	}

}
