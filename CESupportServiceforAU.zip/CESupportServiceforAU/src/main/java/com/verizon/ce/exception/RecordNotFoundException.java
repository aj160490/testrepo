package com.verizon.ce.exception;

public class RecordNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6321725950750002505L;

	public RecordNotFoundException(String message) {
		super(message);
	}

}
