package com.verizon.ce.domains;

import java.util.Map;

public class MediatorPayload {

	private String nfId;
        private String projectId;
        private String caseId;
        private String taskId;
        private String containerId;
        private Map<String,String> pamPayload;
        
		public String getNfId() {
			return nfId;
		}
		public void setNfId(String nfId) {
			this.nfId = nfId;
		}
		public String getProjectId() {
			return projectId;
		}
		public void setProjectId(String projectId) {
			this.projectId = projectId;
		}
		public String getCaseId() {
			return caseId;
		}
		public void setCaseId(String caseId) {
			this.caseId = caseId;
		}
		public String getTaskId() {
			return taskId;
		}
		public void setTaskId(String taskId) {
			this.taskId = taskId;
		}
		public String getContainerId() {
			return containerId;
		}
		public void setContainerId(String containerId) {
			this.containerId = containerId;
		}
		public Map<String, String> getPamPayload() {
			return pamPayload;
		}
		public void setPamPayload(Map<String, String> pamPayload) {
			this.pamPayload = pamPayload;
		}
		@Override
		public String toString() {
			return "MediatorPayload [nfId=" + nfId + ", projectId=" + projectId + ", caseId=" + caseId + ", taskId="
					+ taskId + ", containerId=" + containerId + ", pamPayload=" + pamPayload + "]";
		}

}
