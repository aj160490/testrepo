package com.verizon.ce.domains;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ProcessNode {

	private String name;
	private int id;
	private String type;
	@JsonProperty("process-id")
	private String processId;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getProcessId() {
		return processId;
	}

	public void setProcessId(String processId) {
		this.processId = processId;
	}

}
