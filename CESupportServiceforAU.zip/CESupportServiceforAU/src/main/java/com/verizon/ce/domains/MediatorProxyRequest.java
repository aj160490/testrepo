package com.verizon.ce.domains;

import java.util.List;
import java.util.Map;

public class MediatorProxyRequest {

	private String domainName;
	private List<Map<String,String>> attributes;
	private MediatorPayload payload;
	public String getDomainName() {
		return domainName;
	}
	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}
	public List<Map<String, String>> getAttributes() {
		return attributes;
	}
	public void setAttributes(List<Map<String, String>> attributes) {
		this.attributes = attributes;
	}
	public MediatorPayload getPayload() {
		return payload;
	}
	public void setPayload(MediatorPayload payload) {
		this.payload = payload;
	}
	@Override
	public String toString() {
		return "MediatorProxyRequest [domainName=" + domainName + ", attributes=" + attributes + ", payload=" + payload
				+ "]";
	}
}
