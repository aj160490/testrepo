package com.verizon.ce.domains;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RootNode {
	
	@JsonProperty("process-node")
	ProcessNode[] processNodes;

	public ProcessNode[] getProcessNodes() {
		return processNodes;
	}

	public void setProcessNodes(ProcessNode[] processNodes) {
		this.processNodes = processNodes;
	}
	
	
	

}
