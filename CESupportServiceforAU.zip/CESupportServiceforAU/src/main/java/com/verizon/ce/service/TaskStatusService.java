package com.verizon.ce.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.verizon.ce.apis.TaskServiceApiCalls;
import com.verizon.ce.domains.CaseDetails;
import com.verizon.ce.domains.MediatorPayload;
import com.verizon.ce.domains.MediatorProxyRequest;
import com.verizon.ce.domains.TaskResponse;
import com.verizon.ce.exception.RecordNotFoundException;
import com.verizon.ce.repository.RhpamCaseDetailsRepository;

@Component
public class TaskStatusService {

	@Autowired
	RhpamCaseDetailsRepository caseDetailsRepository;

	@Autowired
	TaskServiceApiCalls taskServiceApiCalls;
	
	static final Logger logger = LoggerFactory.getLogger(TaskStatusService.class);
	
	public CaseDetails getRHPAMCaseId(String nfId) {
		return caseDetailsRepository.findBynfId(nfId);
	}

		public String processRefolowTask(CaseDetails caseDetails) {
		logger.info("Start processRefolowTask()");
		logger.info("caseId : = "+caseDetails.getRHPAM_CASE_ID() + "containerName"+caseDetails.getCONTAINER_NAME());
		String taskStatus= "not completed";
		String taskType= "HumanTaskNode";
		String response = null;
		List<TaskResponse> tasks = taskServiceApiCalls.getTaskResponse(caseDetails.getRHPAM_CASE_ID(), caseDetails.getCONTAINER_NAME(),taskType,taskStatus);
		
		if (tasks.isEmpty()) {
			logger.info("No Tasks found for case id = "+caseDetails.getRHPAM_CASE_ID());
			throw new RecordNotFoundException("No Tasks found for case id := " + caseDetails.getRHPAM_CASE_ID());
		}

		Collections.sort(tasks, Comparator.comparingLong(TaskResponse::getStartDateMillis).reversed());
		logger.info("Task List " + tasks);
		String humanTaskId = tasks.get(0).getHumanTaskId();
		//String taskName = "Manual Task";
		
		String request = TaskStatusService.genrateRequest(caseDetails, humanTaskId);
		
		response = taskServiceApiCalls.startReflowTask(request);
		
		//response = taskServiceApiCalls.startReflowTask(parentContainerId, containerName, taskName);
		
		logger.info("response : "+response);
		 return response;
	}
	
	
	public List<String> getTaskStatus(String caseId, String containerName) {
		
		String taskStatus= "not completed";
		String taskType= "HumanTaskNode";
		List<String> responseMsg = new ArrayList<>();
		logger.info("Start processRefolowTask()");
		logger.info("caseId : = "+caseId + "containerName"+containerName);
		List<TaskResponse> tasks = taskServiceApiCalls.getTaskResponse(caseId, containerName,taskType,taskStatus);
		List<TaskResponse> failedTaskList = null;
		
		if (tasks.isEmpty()) {
			logger.info("No Tasks found for case id = "+caseId);
			throw new RecordNotFoundException("No Tasks found for case id := " + caseId);
		}
		long parentContainerId ;
		Collections.sort(tasks, Comparator.comparingLong(TaskResponse::getStartDateMillis).reversed());
		logger.info("Task List " + tasks.size());
		
		/**for(TaskResponse task : tasks) {
			parentContainerId = task.getParentContainerId();
			logger.info("ParentContainerId := " + parentContainerId );	
			taskStatus= "failing";
			taskType= "";
			failedTaskList = taskServiceApiCalls.getTaskResponse(String.valueOf(parentContainerId), containerName,taskType,taskStatus);
			//responseMsg.add('Failed tasks List:');
			for(TaskResponse tr :failedTaskList ) {
				responseMsg.add(tr.getTaskName());
				logger.info("The task "+ tr.getTaskName() +" is in failed status.");
			}
		}*/
		TaskResponse task = tasks.get(0);
		parentContainerId = task.getParentContainerId();
		logger.info("ParentContainerId := " + parentContainerId );	
		taskStatus= "failing";
		taskType= "";
		failedTaskList = taskServiceApiCalls.getTaskResponse(String.valueOf(parentContainerId), containerName,taskType,taskStatus);
		for(TaskResponse tr :failedTaskList ) {
			responseMsg.add(tr.getTaskName());
			logger.info("The task "+ tr.getTaskName() +" is in failed status.");
		}
		return responseMsg;
	}
	
	private static String genrateRequest(CaseDetails caseDetails , String taskId) {
		
		
		MediatorProxyRequest request = new MediatorProxyRequest();
		
		List <Map<String,String>> attrLst= new ArrayList <Map<String,String>> ();
		HashMap<String, String> attribute = new HashMap<String, String>();
		attribute.put("name", "mediatorProxyName");
		attribute.put("value", "Submit-Common-UI-CloseTask");
		attrLst.add(attribute);
		
		HashMap<String, String> pamPayload = new HashMap<String, String>();
		pamPayload.put("isRetry", "true");
				
		MediatorPayload payload = new MediatorPayload();
		payload.setNfId(caseDetails.getNfId());
		payload.setProjectId(caseDetails.getPROJECT_ID());
		payload.setCaseId(caseDetails.getRHPAM_CASE_ID());
		payload.setContainerId(caseDetails.getCONTAINER_NAME());
		payload.setTaskId(taskId);
		payload.setPamPayload(pamPayload);
		
		request.setDomainName("F86V-ENGG-IN");
		request.setAttributes(attrLst);
		request.setPayload(payload);
		
		String jsonRequest = null;
		try {
			ObjectMapper obj = new ObjectMapper();
			jsonRequest = obj.writeValueAsString(request);
		} catch (JsonProcessingException e) {
			logger.error("Error while Json request parsering",e.getMessage());
			e.printStackTrace();
			throw new RecordNotFoundException("Error while Json request parsering := " + e.getMessage());
		}
		
		return jsonRequest;
	}
	
	
		
}
