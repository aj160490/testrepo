package com.verizon.ce.domains;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(schema = "WFM_NF", name = "NF_RHPAM_CASE_DETAILS")
public class CaseDetails {
	
	@Id
	private String ID;
	@Column(name =  "NF_ID")
	private String nfId;
	private String PROJECT_ID;
	private String RHPAM_CASE_ID;
	private String CONTAINER_NAME;
	private String CREATED_DATE;
	public String getID() {
		return ID;
	}
	
	
	public String getNfId() {
		return nfId;
	}


	public void setNfId(String nfId) {
		this.nfId = nfId;
	}


	public void setID(String iD) {
		ID = iD;
	}


	public String getPROJECT_ID() {
		return PROJECT_ID;
	}
	public void setPROJECT_ID(String pROJECT_ID) {
		PROJECT_ID = pROJECT_ID;
	}
	public String getRHPAM_CASE_ID() {
		return RHPAM_CASE_ID;
	}
	public void setRHPAM_CASE_ID(String rHPAM_CASE_ID) {
		RHPAM_CASE_ID = rHPAM_CASE_ID;
	}
	public String getCONTAINER_NAME() {
		return CONTAINER_NAME;
	}
	public void setCONTAINER_NAME(String cONTAINER_NAME) {
		CONTAINER_NAME = cONTAINER_NAME;
	}
	public String getCREATED_DATE() {
		return CREATED_DATE;
	}
	public void setCREATED_DATE(String cREATED_DATE) {
		CREATED_DATE = cREATED_DATE;
	}

}
