package com.verizon.ce.exception;

public class ReflowTaskUnsuccessfullException extends RuntimeException {


	public ReflowTaskUnsuccessfullException(String message) {
		super(message);
	}

}
