package com.verizon.ce.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;

import com.verizon.ce.domains.CaseDetails;
import com.verizon.ce.exception.RecordNotFoundException;
import com.verizon.ce.exception.ReflowTaskUnsuccessfullException;
import com.verizon.ce.service.TaskStatusService;

@Component
public class TaskStatusTreeControllerImpl implements TaskStatusTreeController {

	@Autowired
	TaskStatusService taskStatusService;
	
	static final Logger logger = LoggerFactory.getLogger(TaskStatusTreeControllerImpl.class);
	
	@Override
	public ResponseEntity<Map<String ,String>> reflowTaskUsingNfId(String nfId) {
		CaseDetails caseDetails = null;
		String errorMsg = null;
		Map<String, String> responseJson = new HashMap<String, String>() ;
		String response =null;
		logger.info("nfId : = "+nfId);
		try {
			caseDetails = taskStatusService.getRHPAMCaseId(nfId);
			logger.info("caseDetails : = "+caseDetails);
			
			if (caseDetails == null) {
				logger.error("RHPAM case Id not found for nfId ");
				errorMsg="RHPAM case Id not found for nfId"+ nfId;
				responseJson.put("Status",errorMsg);
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(responseJson);
			}
		} catch (Exception e) {
			logger.error("Error during fetching RHPAM case Id :- "+e.getMessage());
			errorMsg="Error during fetching RHPAM case Id "+ e.getMessage();
			responseJson.put("Status",e.getMessage());
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(responseJson);
		}
		
		try {
			response = taskStatusService.processRefolowTask(caseDetails);
		} catch (RestClientException e) {
			logger.error(""+HttpStatus.INTERNAL_SERVER_ERROR);
			responseJson.put("Status",e.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(responseJson);
		} catch (RecordNotFoundException e2) {
			logger.error(""+HttpStatus.NOT_FOUND);
			responseJson.put("Status",e2.getMessage());
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(responseJson);
		} catch (ReflowTaskUnsuccessfullException e3) {
			logger.error(""+HttpStatus.EXPECTATION_FAILED);
			responseJson.put("Status",e3.getMessage());
			return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(responseJson);
		}
		logger.info("Reflow Process Successfully Executed ");
		responseJson.put("Success",response);
		return ResponseEntity.status(HttpStatus.OK).body(responseJson);
	}

	@Override
	public ResponseEntity<Map<String, List<String>>> getFailureReason(String nfId) {
		CaseDetails caseDetails = null;
		logger.info("nfId : = " + nfId);
		List<String> responseMsg = null;
		List<String> errorLst = new ArrayList<>();
		Map<String, List<String>> responseJson = new HashMap<String, List<String>>();
		try {
			caseDetails = taskStatusService.getRHPAMCaseId(nfId);
			logger.info("caseDetails : = " + caseDetails);

			if (caseDetails == null) {
				logger.error("RHPAM case Id not found for nfId ");
				errorLst.add("RHPAM case Id not found for nfId" + nfId);
				responseJson.put("Error", errorLst);
				responseJson.put("No Manual task Found For this nfId", null);
				return ResponseEntity.status(HttpStatus.OK).body(responseJson);
			}
		} catch (Exception e) {
			logger.error("Error during fetching RHPAM case Id :- " + e);
			errorLst.add("Error during fetching RHPAM case Id " + e.getMessage());
			responseJson.put("Error", errorLst);
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(responseJson);
		}

		try {
			responseMsg = taskStatusService.getTaskStatus(caseDetails.getRHPAM_CASE_ID(),
					caseDetails.getCONTAINER_NAME());
			responseJson.put("Failed Task List ", responseMsg);
		} catch (RestClientException e) {
			logger.error("" + HttpStatus.INTERNAL_SERVER_ERROR);
			errorLst.add(e.getMessage());
			responseJson.put("Error", errorLst);
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(responseJson);
		} catch (RecordNotFoundException e2) {
			logger.error("" + HttpStatus.NOT_FOUND);
			errorLst.add(e2.getMessage());
			responseJson.put("Error", errorLst);
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(responseJson);
		} catch (ReflowTaskUnsuccessfullException e3) {
			logger.error("" + HttpStatus.EXPECTATION_FAILED);
			errorLst.removeAll(errorLst);
			errorLst.add(e3.getMessage());
			responseJson.put("Error", errorLst);
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(responseJson);

		}

		logger.info("Get Process Status Successfully Executed ");

		return ResponseEntity.status(HttpStatus.OK).body(responseJson);
	} 
	
	

}
